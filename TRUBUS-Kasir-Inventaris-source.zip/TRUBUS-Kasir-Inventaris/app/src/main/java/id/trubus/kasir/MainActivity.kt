package id.trubus.kasir

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CartLine(val product: Product, var qty: Int, val price: Long)

class MainActivity : Activity() {
    private lateinit var db: TrubusDb
    private lateinit var content: LinearLayout
    private val cart = mutableListOf<CartLine>()
    private var paymentType = "CASH"
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TrubusDb(this)
        showHome()
    }

    private fun root(title: String): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xFFF5F7F4.toInt())
        }
        val header = TextView(this).apply {
            text = "TRUBUS  •  $title"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF176B3A.toInt())
            setPadding(0, 0, 0, 16)
        }
        outer.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val scroll = ScrollView(this).apply { addView(outer) }
        setContentView(scroll)
        return content
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(0xFF202820.toInt())
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 8, 0, 8)
    }

    private fun showHome() {
        val c = root("Kasir & Inventaris")
        val summary = db.salesSummary()
        c.addView(text("Penjualan tersimpan: ${summary.first} transaksi", 16f, true))
        c.addView(text("Total penjualan: ${rupiah.format(summary.second)}"))
        c.addView(button("🛒  Buka Kasir") { showCashier() })
        c.addView(button("📦  Produk & Stok") { showProducts() })
        c.addView(button("＋  Tambah Produk") { showAddProduct() })
        c.addView(button("📊  Ringkasan Penjualan") { showSales() })
        c.addView(button("🖨  Cetak struk Bluetooth") { bluetoothPrintInfo() })
        c.addView(text("Versi fondasi 0.1 • Data disimpan di HP • Dapat digunakan offline", 12f))
        c.addView(text("Produk contoh tersedia untuk uji coba. Ganti atau tambahkan produk asli.", 12f))
    }

    private fun showProducts() {
        val c = root("Produk & Stok")
        c.addView(button("＋ Tambah produk") { showAddProduct() })
        val products = db.allProducts()
        if (products.isEmpty()) c.addView(text("Belum ada produk."))
        products.forEach { p ->
            c.addView(text("${p.name}\nBarcode: ${p.barcode} • Stok: ${p.stock}\nModal ${rupiah.format(p.cost)} | Cash ${rupiah.format(p.cashPrice)} | Hutang ${rupiah.format(p.debtPrice)}", 14f))
            c.addView(View(this).apply { setBackgroundColor(0xFFDCE5DC.toInt()) },
                LinearLayout.LayoutParams(-1, 1))
        }
        c.addView(button("← Kembali") { showHome() })
    }

    private fun showAddProduct() {
        val c = root("Tambah Produk")
        val name = field("Nama produk")
        val barcode = field("Barcode (unik)")
        val cost = field("Modal per satuan (angka)")
        val cash = field("Harga cash (angka)")
        val debt = field("Harga hutang (angka)")
        val stock = field("Stok awal (angka)")
        listOf(name, barcode, cost, cash, debt, stock).forEach { c.addView(it) }
        c.addView(button("Simpan produk") {
            val ok = name.text.isNotBlank() && barcode.text.isNotBlank() &&
                cost.text.toString().toLongOrNull() != null &&
                cash.text.toString().toLongOrNull() != null &&
                debt.text.toString().toLongOrNull() != null &&
                stock.text.toString().toIntOrNull() != null
            if (!ok) {
                Toast.makeText(this, "Isi semua kolom dengan benar.", Toast.LENGTH_LONG).show()
            } else {
                val saved = db.addProduct(name.text.toString(), barcode.text.toString(),
                    cost.text.toString().toLong(), cash.text.toString().toLong(),
                    debt.text.toString().toLong(), stock.text.toString().toInt())
                if (saved) {
                    Toast.makeText(this, "Produk disimpan.", Toast.LENGTH_SHORT).show()
                    showProducts()
                } else Toast.makeText(this, "Gagal. Barcode mungkin sudah digunakan.", Toast.LENGTH_LONG).show()
            }
        })
        c.addView(button("Batal") { showProducts() })
    }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 16f
        singleLine = true
        setPadding(12, 4, 12, 4)
    }

    private fun showCashier() {
        val c = root("Kasir")
        val search = field("Cari nama / masukkan barcode")
        c.addView(search)
        val mode = Spinner(this)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("CASH", "HUTANG"))
        c.addView(text("Jenis harga"))
        c.addView(mode)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)
        val cartText = text("", 15f, true)
        c.addView(cartText)
        fun redraw() {
            list.removeAllViews()
            val query = search.text.toString().trim()
            db.allProducts().filter { query.isBlank() || it.name.contains(query, true) || it.barcode.contains(query, true) }
                .forEach { p ->
                    val price = if (mode.selectedItem?.toString() == "HUTANG") p.debtPrice else p.cashPrice
                    list.addView(button("${p.name} • stok ${p.stock}\n${rupiah.format(price)}  |  Tambah") {
                        val existing = cart.indexOfFirst { it.product.id == p.id && it.price == price }
                        if (p.stock <= 0) Toast.makeText(this, "Stok habis.", Toast.LENGTH_SHORT).show()
                        else if (existing >= 0) cart[existing].qty++
                        else cart.add(CartLine(p, 1, price))
                        updateCartLabel(cartText)
                    })
                }
            updateCartLabel(cartText)
        }
        search.addTextChangedListener(SimpleWatcher { redraw() })
        mode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { redraw() }
        }
        redraw()
        c.addView(button("Hapus keranjang") { cart.clear(); updateCartLabel(cartText) })
        c.addView(button("Selesaikan transaksi") {
            if (cart.isEmpty()) {
                Toast.makeText(this, "Keranjang masih kosong.", Toast.LENGTH_SHORT).show()
            } else {
                paymentType = mode.selectedItem.toString()
                val total = cart.sumOf { it.price * it.qty }
                val paidField = field("Uang diterima (angka). Untuk hutang isi 0 bila belum bayar.")
                paidField.setText(if (paymentType == "CASH") total.toString() else "0")
                AlertDialog.Builder(this)
                    .setTitle("Konfirmasi transaksi")
                    .setMessage("Total: ${rupiah.format(total)}\nTipe harga: $paymentType")
                    .setView(paidField)
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Simpan") { _, _ ->
                        val paid = paidField.text.toString().toLongOrNull()
                        if (paid == null || paid < 0) {
                            Toast.makeText(this, "Nominal pembayaran tidak valid.", Toast.LENGTH_LONG).show()
                        } else {
                            val saleId = db.saveSale(cart.toList(), paymentType, paid, null)
                            val copy = cart.toList()
                            cart.clear()
                            showReceipt(saleId, copy, total, paid, paymentType)
                        }
                    }.show()
            }
        })
        c.addView(button("← Kembali") { showHome() })
    }

    private fun updateCartLabel(label: TextView) {
        val count = cart.sumOf { it.qty }
        val total = cart.sumOf { it.price * it.qty }
        label.text = "Keranjang: $count barang\nTotal: ${rupiah.format(total)}"
    }

    private fun showReceipt(id: Long, items: List<CartLine>, total: Long, paid: Long, type: String) {
        val c = root("Struk Transaksi")
        val date = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id", "ID")).format(Date())
        val due = (total - paid).coerceAtLeast(0)
        val receipt = buildString {
            appendLine("KIOS PERTANIAN TRUBUS")
            appendLine("No: TRB-${id.toString().padStart(6, '0')}")
            appendLine(date)
            appendLine("--------------------------------")
            items.forEach { appendLine("${it.product.name} x${it.qty}")
                appendLine("  ${rupiah.format(it.price)} x ${it.qty} = ${rupiah.format(it.price * it.qty)}") }
            appendLine("--------------------------------")
            appendLine("Jenis: $type")
            appendLine("TOTAL: ${rupiah.format(total)}")
            appendLine("DIBAYAR: ${rupiah.format(paid)}")
            appendLine("SISA: ${rupiah.format(due)}")
            appendLine("Terima kasih")
        }
        c.addView(text(receipt, 15f))
        c.addView(button("Cetak via Bluetooth (tahap berikutnya)") { bluetoothPrintInfo() })
        c.addView(button("Kembali ke beranda") { showHome() })
    }

    private fun showSales() {
        val c = root("Ringkasan")
        val s = db.salesSummary()
        c.addView(text("Jumlah transaksi: ${s.first}", 18f, true))
        c.addView(text("Total penjualan tersimpan: ${rupiah.format(s.second)}"))
        c.addView(text("Laba per transaksi, filter periode, pengeluaran, piutang terperinci, dan ekspor akan ditambahkan pada tahap berikutnya."))
        c.addView(button("← Kembali") { showHome() })
    }

    private fun bluetoothPrintInfo() {
        val message = if (Build.VERSION.SDK_INT >= 31)
            "Fondasi ini belum mengirim data ke printer. Tahap printer akan meminta izin Bluetooth Android 12+ lalu memilih printer ESC/POS yang sudah dipasangkan di Pengaturan Bluetooth."
        else
            "Fondasi ini belum mengirim data ke printer. Tahap printer akan memilih printer ESC/POS yang sudah dipasangkan."
        AlertDialog.Builder(this).setTitle("Printer Bluetooth").setMessage(message)
            .setPositiveButton("Mengerti", null).show()
    }
}

private class SimpleWatcher(val onChange: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChange() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
