package id.trubus.kasir

data class Product(
    val id: Long = 0,
    val name: String,
    val barcode: String,
    val cost: Long,
    val cashPrice: Long,
    val debtPrice: Long,
    val stock: Int
)
