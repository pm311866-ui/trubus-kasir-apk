package id.trubus.kasir

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TrubusDb(context: Context) : SQLiteOpenHelper(context, "trubus.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                barcode TEXT NOT NULL UNIQUE,
                cost INTEGER NOT NULL,
                cash_price INTEGER NOT NULL,
                debt_price INTEGER NOT NULL,
                stock INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE sales(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                payment_type TEXT NOT NULL,
                total INTEGER NOT NULL,
                paid INTEGER NOT NULL,
                note TEXT
            )"""
        )
        db.execSQL(
            """CREATE TABLE sale_items(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                qty INTEGER NOT NULL,
                unit_price INTEGER NOT NULL,
                unit_cost INTEGER NOT NULL,
                FOREIGN KEY(sale_id) REFERENCES sales(id)
            )"""
        )
        val sample = ContentValues().apply {
            put("name", "Pupuk NPK Mutiara (contoh)")
            put("barcode", "TRB000001")
            put("cost", 250000)
            put("cash_price", 280000)
            put("debt_price", 300000)
            put("stock", 10)
        }
        db.insert("products", null, sample)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun allProducts(): List<Product> {
        val result = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name", null).use { c ->
            while (c.moveToNext()) {
                result += Product(
                    id = c.getLong(c.getColumnIndexOrThrow("id")),
                    name = c.getString(c.getColumnIndexOrThrow("name")),
                    barcode = c.getString(c.getColumnIndexOrThrow("barcode")),
                    cost = c.getLong(c.getColumnIndexOrThrow("cost")),
                    cashPrice = c.getLong(c.getColumnIndexOrThrow("cash_price")),
                    debtPrice = c.getLong(c.getColumnIndexOrThrow("debt_price")),
                    stock = c.getInt(c.getColumnIndexOrThrow("stock"))
                )
            }
        }
        return result
    }

    fun addProduct(name: String, barcode: String, cost: Long, cash: Long, debt: Long, stock: Int): Boolean {
        return try {
            val values = ContentValues().apply {
                put("name", name.trim())
                put("barcode", barcode.trim())
                put("cost", cost)
                put("cash_price", cash)
                put("debt_price", debt)
                put("stock", stock)
            }
            writableDatabase.insertOrThrow("products", null, values) > 0
        } catch (_: Exception) { false }
    }

    fun saveSale(items: List<CartLine>, paymentType: String, paid: Long, note: String?): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val total = items.sumOf { it.price * it.qty }
            val sale = ContentValues().apply {
                put("created_at", System.currentTimeMillis())
                put("payment_type", paymentType)
                put("total", total)
                put("paid", paid)
                put("note", note ?: "")
            }
            val saleId = db.insertOrThrow("sales", null, sale)
            items.forEach { line ->
                val item = ContentValues().apply {
                    put("sale_id", saleId)
                    put("product_id", line.product.id)
                    put("product_name", line.product.name)
                    put("qty", line.qty)
                    put("unit_price", line.price)
                    put("unit_cost", line.product.cost)
                }
                db.insertOrThrow("sale_items", null, item)
                db.execSQL("UPDATE products SET stock = stock - ? WHERE id = ?",
                    arrayOf(line.qty, line.product.id))
            }
            db.setTransactionSuccessful()
            return saleId
        } finally {
            db.endTransaction()
        }
    }

    fun salesSummary(): Pair<Int, Long> {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(total),0) FROM sales", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0) to c.getLong(1)
        }
        return 0 to 0L
    }
}
