# TRUBUS Kasir & Inventaris — fondasi Android 0.1

Ini adalah proyek awal native Android (Kotlin) untuk dikembangkan dan diuji di Android Studio.

## Yang sudah diimplementasikan
- Database lokal SQLite; fungsi dasar dapat dipakai offline.
- Contoh produk awal untuk uji coba.
- Daftar produk dan stok.
- Tambah produk dengan modal, harga cash, harga hutang, stok, dan barcode unik.
- Kasir dasar dengan pencarian nama/barcode teks dan pemilihan harga cash/hutang.
- Simpan transaksi, kurangi stok, dan tampilkan struk di layar.
- Ringkasan jumlah transaksi dan total penjualan.

## Belum diimplementasikan (jangan dianggap sudah tersedia)
- Cetak fisik Bluetooth ESC/POS; saat ini hanya informasi placeholder.
- Pemindaian barcode kamera.
- PIN dan hak akses pengguna.
- Diskon, pelanggan/piutang yang terstruktur, transfer, retur, pengeluaran, dan laporan periode/laba.
- Impor Excel, label massal, backup/pemulihan UI, sinkronisasi multi-perangkat.
- Tes otomatis dan pengujian pada perangkat fisik.

## Cara membuka dan membangun APK
1. Pasang Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder `TRUBUS-Kasir-Inventaris`.
4. Izinkan Gradle mengunduh Android Gradle Plugin/Kotlin plugin jika diminta.
5. Pilih SDK Android 35 di SDK Manager (atau sesuaikan `compileSdk` dengan SDK yang tersedia).
6. Tunggu Gradle Sync selesai.
7. Jalankan pada emulator/perangkat Android melalui Run.
8. Untuk APK debug: Build > Build Bundle(s) / APK(s) > Build APK(s).
9. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Uji manual awal
1. Buka Produk & Stok; pastikan produk contoh terlihat.
2. Tambah produk dengan barcode unik, misalnya `TRB000002`.
3. Buka Kasir; cari produk berdasarkan nama atau teks barcode.
4. Pilih CASH, tambahkan produk, selesaikan transaksi dengan pembayaran penuh.
5. Ulangi dengan HUTANG dan uang diterima 0; struk menampilkan sisa tagihan, tetapi belum ada buku piutang pelanggan.
6. Periksa stok berkurang setelah transaksi.

## Catatan penting
- Contoh produk dan angka harga hanyalah data uji. Hapus/ganti sebelum penggunaan nyata.
- Ini fondasi prototipe, belum siap untuk operasional toko tanpa pengembangan dan pengujian lanjutan.
- Untuk printer, konfirmasi model printer Bluetooth. Printer struk umumnya memakai ESC/POS; printer label bisa menggunakan protokol/vendor berbeda.


## Build APK langsung dari HP dengan GitHub Actions
Proyek ini menyertakan workflow `.github/workflows/android-apk.yml` untuk membangun APK di server GitHub.
1. Di browser HP, buat akun/masuk ke GitHub dan buat repository baru.
2. Unggah seluruh isi folder proyek (termasuk folder tersembunyi `.github/workflows`) ke repository, atau unggah ZIP lalu ekstrak di lingkungan yang mendukung Git. GitHub web upload tidak selalu memudahkan folder tersembunyi; pastikan file workflow ikut terunggah.
3. Buka tab Actions di repository dan jalankan workflow "Build TRUBUS Android APK" jika belum otomatis berjalan.
4. Setelah proses sukses, buka run terbaru, cari bagian Artifacts, unduh `TRUBUS-debug-APK.zip`, lalu ekstrak di HP untuk memperoleh `app-debug.apk`.
5. Buka APK di HP dan izinkan pemasangan dari sumber tersebut jika Android memintanya.

Jika workflow gagal, buka log build dan periksa pesan error. APK debug hanya untuk uji coba; proyek ini masih prototipe, belum siap untuk operasional toko.
